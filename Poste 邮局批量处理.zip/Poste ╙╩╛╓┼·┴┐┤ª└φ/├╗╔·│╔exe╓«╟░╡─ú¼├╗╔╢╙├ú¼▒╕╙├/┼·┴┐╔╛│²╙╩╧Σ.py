import requests
import base64
import os

# 输入管理员邮箱和密码
admin_email = input("请输入管理员邮箱（例如 admin@accvcc.com）：").strip()
admin_pass = input("请输入管理员密码：").strip()

# 提取域名
domain = admin_email.split('@')[-1]

# 生成 Basic Auth
auth_str = f"{admin_email}:{admin_pass}"
auth_b64 = base64.b64encode(auth_str.encode()).decode()

headers = {
    "Authorization": f"Basic {auth_b64}",
    "Content-Type": "application/json"
}

api_base_url = "https://mail.accvcc.com/admin/api/v1/boxes"

input_file = "待删除邮箱.txt"
success_file = "已删除.txt"

if not os.path.exists(input_file):
    print(f"❌ 文件不存在：{input_file}")
    input("按回车退出...")
    exit()

with open(input_file, "r", encoding="utf-8") as f:
    lines = [line.strip() for line in f if line.strip()]

success_count = 0

for line in lines:
    parts = line.split()
    local_part = parts[0]  # 支持 仅邮箱 或 邮箱 + 密码
    if '@' not in local_part:
        email = f"{local_part}@{domain}"
    else:
        email = local_part

    url = f"{api_base_url}/{email}"
    try:
        resp = requests.delete(url, headers=headers)
        if resp.status_code in [200, 204]:
            print(f"✅ {email} 删除成功")
            with open(success_file, "a", encoding="utf-8") as sf:
                sf.write(f"{email}\n")
            success_count += 1
        else:
            print(f"❌ {email} 删除失败: {resp.status_code} | {resp.text}")
    except Exception as e:
        print(f"❌ {email} 请求异常: {e}")

print(f"\n🗑️ 共成功删除 {success_count} 个邮箱账号。")
input("按回车退出...")
