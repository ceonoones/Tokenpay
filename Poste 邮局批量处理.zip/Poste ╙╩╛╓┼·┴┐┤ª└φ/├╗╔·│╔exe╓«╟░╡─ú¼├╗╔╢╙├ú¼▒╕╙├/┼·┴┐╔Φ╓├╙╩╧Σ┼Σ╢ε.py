import requests
from requests.auth import HTTPBasicAuth
import os

# ========== 基础信息 ==========
MAIL_DOMAIN = "accvcc.com"
API_BASE = f"https://mail.{MAIL_DOMAIN}/admin/api/v1/boxes"
INPUT_FILE = "待配额邮箱.txt"
OUTPUT_FILE = "设置成功.txt"

# ========== 管理员信息 ==========
admin_email = input("请输入管理员邮箱（如 admin@accvcc.com）：").strip()
admin_password = input("请输入管理员密码：").strip()

# ========== 配额大小输入 ==========
while True:
    quota_input = input("请输入要设置的配额大小（单位 MB，范围 1~102400）：").strip()
    if quota_input.isdigit() and 1 <= int(quota_input) <= 102400:
        quota_mb = int(quota_input)
        break
    else:
        print("❌ 请输入合法的整数（范围 1~102400）")

# ========== 开始读取并设置 ==========
success_list = []
fail_count = 0

if not os.path.exists(INPUT_FILE):
    print(f"❌ 文件不存在：{INPUT_FILE}")
    input("\n按回车退出...")
    exit()

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    lines = f.readlines()

for line in lines:
    line = line.strip()
    if not line:
        continue

    # 提取邮箱
    parts = line.split("\t")[0].strip()
    if "@" in parts:
        email = parts
    else:
        email = f"{parts}@{MAIL_DOMAIN}"

    # 请求 PATCH 修改配额
    payload = {
        "storageLimit": quota_mb,
        "countLimit": 0
    }

    try:
        res = requests.patch(f"{API_BASE}/{email}/quota", auth=HTTPBasicAuth(admin_email, admin_password), json=payload)
        if res.status_code in [200, 204]:
            print(f"✅ {email} 配额设置成功")
            success_list.append(email)
        else:
            print(f"❌ {email} 设置失败: {res.status_code} | {res.text}")
            fail_count += 1
    except Exception as e:
        print(f"❌ {email} 设置异常: {e}")
        fail_count += 1

# ========== 写入成功记录 ==========
if success_list:
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(success_list))

# ========== 完成提示 ==========
print(f"\n🎯 设置完成：成功 {len(success_list)} 个，失败 {fail_count} 个")
print(f"📄 设置成功的邮箱保存至：{OUTPUT_FILE}")
input("\n✅ 按回车退出...")
