import requests
import base64
import os

# 用户输入管理员邮箱和密码
admin_email = input("请输入管理员邮箱（例如 admin@accvcc.com）：").strip()
admin_pass = input("请输入管理员密码：").strip()

# 编码 Basic Auth 认证信息
auth_str = f"{admin_email}:{admin_pass}"
auth_b64 = base64.b64encode(auth_str.encode()).decode()

headers = {
    "Authorization": f"Basic {auth_b64}",
    "Content-Type": "application/json"
}

api_url = "https://mail.accvcc.com/admin/api/v1/boxes"

# 读取邮箱数据文件
input_file = "待生成邮箱.txt"
success_file = "成功.txt"

if not os.path.exists(input_file):
    print(f"❌ 文件不存在：{input_file}")
    input("按回车退出...")
    exit()

with open(input_file, "r", encoding="utf-8") as f:
    lines = f.readlines()

success_count = 0

for line in lines:
    line = line.strip()
    if not line or "\t" not in line:
        continue

    username, password = line.split("\t")
    email = f"{username}@accvcc.com"

    payload = {
        "name": username,
        "email": email,
        "passwordPlaintext": password,
        "disabled": False,
        "superAdmin": False,
        "redirectTo": [],
        "referenceId": ""
    }

    try:
        resp = requests.post(api_url, headers=headers, json=payload)
        if resp.status_code in [200, 201]:
            print(f"✅ {email} 创建成功")
            with open(success_file, "a", encoding="utf-8") as sf:
                sf.write(f"{email}\t{password}\n")
            success_count += 1
        else:
            print(f"❌ {email} 创建失败: {resp.status_code} | {resp.text}")
    except Exception as e:
        print(f"❌ {email} 请求异常: {e}")

print(f"\n🎉 共成功创建 {success_count} 个邮箱。")
input("按回车退出...")
