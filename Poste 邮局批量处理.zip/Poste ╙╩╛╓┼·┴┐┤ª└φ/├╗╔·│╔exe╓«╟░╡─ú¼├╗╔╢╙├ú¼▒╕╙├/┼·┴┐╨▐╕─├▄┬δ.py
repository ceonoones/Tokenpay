import requests
from requests.auth import HTTPBasicAuth
import os

# ========== 基础信息 ==========
MAIL_DOMAIN = "accvcc.com"
API_BASE = f"https://mail.{MAIL_DOMAIN}/admin/api/v1/boxes"
INPUT_FILE = "修改密码.txt"
OUTPUT_FILE = "修改成功.txt"

# ========== 管理员信息 ==========
admin_email = input("请输入管理员邮箱（如 admin@accvcc.com）：").strip()
admin_password = input("请输入管理员密码：").strip()

# ========== 检查输入文件 ==========
if not os.path.exists(INPUT_FILE):
    print(f"❌ 文件不存在：{INPUT_FILE}")
    input("\n按回车退出...")
    exit()

# ========== 执行批量修改 ==========
success_list = []
fail_count = 0

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    lines = f.readlines()

for line in lines:
    line = line.strip()
    if not line or "\t" not in line:
        continue

    username, password = line.split("\t", 1)
    username = username.strip()
    password = password.strip()

    # 判断是否是完整邮箱
    if "@" in username:
        email = username
    else:
        email = f"{username}@{MAIL_DOMAIN}"

    payload = {
        "passwordPlaintext": password
    }

    try:
        res = requests.patch(f"{API_BASE}/{email}", auth=HTTPBasicAuth(admin_email, admin_password), json=payload)
        if res.status_code in [200, 204]:
            print(f"✅ {email} 修改密码成功")
            success_list.append(f"{email}\t{password}")
        else:
            print(f"❌ {email} 修改失败: {res.status_code} | {res.text}")
            fail_count += 1
    except Exception as e:
        print(f"❌ {email} 请求异常: {e}")
        fail_count += 1

# ========== 写入成功记录 ==========
if success_list:
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(success_list))

# ========== 完成提示 ==========
print(f"\n🎯 密码修改完成：成功 {len(success_list)} 个，失败 {fail_count} 个")
print(f"📄 成功列表已保存至：{OUTPUT_FILE}")
input("\n✅ 按回车退出...")
