
import requests
from requests.auth import HTTPBasicAuth
import os

def get_mail_domain():
    domain = input("请输入你的邮件服务器域名（如 https://mail.accvcc.com）：").strip().rstrip("/")
    if not domain.startswith("http"):
        domain = "https://" + domain
    return domain

def get_admin_credentials():
    email = input("请输入管理员邮箱（如 admin@accvcc.com）：").strip()
    password = input("请输入管理员密码：").strip()
    return email, password

def load_input_file():
    path = input("请拖入你的账号数据 TXT 文件：").strip('"')
    if not os.path.exists(path):
        print(f"❌ 文件不存在：{path}")
        input("按回车退出...")
        exit()
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def parse_line(line, need_password=False):
    parts = line.split("\t")
    if len(parts) == 1:
        user = parts[0]
        pwd = None
    else:
        user, pwd = parts[0], parts[1]
    email = user if "@" in user else f"{user}@{MAIL_DOMAIN}"
    return email, pwd if need_password else None

def create_mailboxes():
    data = load_input_file()
    success, failed = [], 0
    for line in data:
        email, pwd = parse_line(line, need_password=True)
        payload = {
            "email": email,
            "passwordPlaintext": pwd
        }
        try:
            res = requests.post(f"{API_BASE}", auth=HTTPBasicAuth(ADMIN_EMAIL, ADMIN_PASSWORD), json=payload)
            if res.status_code == 201:
                print(f"✅ {email} 创建成功")
                success.append(f"{email}\t{pwd}")
            else:
                print(f"❌ {email} 创建失败: {res.status_code} | {res.text}")
                failed += 1
        except Exception as e:
            print(f"❌ {email} 请求失败: {e}")
            failed += 1
    if success:
        with open("创建成功.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(success))
    print(f"\n🎯 完成：成功 {len(success)} 个，失败 {failed} 个")
    input("按回车退出...")

def delete_mailboxes():
    data = load_input_file()
    success, failed = [], 0
    for line in data:
        email, _ = parse_line(line)
        try:
            res = requests.delete(f"{API_BASE}/{email}", auth=HTTPBasicAuth(ADMIN_EMAIL, ADMIN_PASSWORD))
            if res.status_code in [200, 204]:
                print(f"🗑️ {email} 删除成功")
                success.append(email)
            else:
                print(f"❌ {email} 删除失败: {res.status_code} | {res.text}")
                failed += 1
        except Exception as e:
            print(f"❌ {email} 请求失败: {e}")
            failed += 1
    if success:
        with open("删除成功.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(success))
    print(f"\n🧹 删除完成：成功 {len(success)} 个，失败 {failed} 个")
    input("按回车退出...")

def update_quotas():
    data = load_input_file()
    while True:
        q = input("请输入要设置的配额（单位 MB，范围 1~102400）：").strip()
        if q.isdigit() and 1 <= int(q) <= 102400:
            quota = int(q)
            break
    success, failed = [], 0
    for line in data:
        email, _ = parse_line(line)
        payload = {
            "storageLimit": quota,
            "countLimit": 0
        }
        try:
            res = requests.patch(f"{API_BASE}/{email}/quota", auth=HTTPBasicAuth(ADMIN_EMAIL, ADMIN_PASSWORD), json=payload)
            if res.status_code in [200, 204]:
                print(f"📦 {email} 配额设置成功")
                success.append(email)
            else:
                print(f"❌ {email} 设置失败: {res.status_code} | {res.text}")
                failed += 1
        except Exception as e:
            print(f"❌ {email} 请求失败: {e}")
            failed += 1
    if success:
        with open("设置成功.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(success))
    print(f"\n🎯 配额设置完成：成功 {len(success)} 个，失败 {failed} 个")
    input("按回车退出...")

def update_passwords():
    data = load_input_file()
    success, failed = [], 0
    for line in data:
        email, pwd = parse_line(line, need_password=True)
        if not pwd:
            print(f"⚠️ 忽略 {email}：无密码")
            continue
        payload = {
            "passwordPlaintext": pwd
        }
        try:
            res = requests.patch(f"{API_BASE}/{email}", auth=HTTPBasicAuth(ADMIN_EMAIL, ADMIN_PASSWORD), json=payload)
            if res.status_code in [200, 204]:
                print(f"🔐 {email} 密码修改成功")
                success.append(f"{email}\t{pwd}")
            else:
                print(f"❌ {email} 修改失败: {res.status_code} | {res.text}")
                failed += 1
        except Exception as e:
            print(f"❌ {email} 请求异常: {e}")
            failed += 1
    if success:
        with open("修改成功.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(success))
    print(f"\n🎯 密码修改完成：成功 {len(success)} 个，失败 {failed} 个")
    input("按回车退出...")

# 主程序
MAIL_DOMAIN = get_mail_domain().replace("https://mail.", "")
API_BASE = f"https://mail.{MAIL_DOMAIN}/admin/api/v1/boxes"
ADMIN_EMAIL, ADMIN_PASSWORD = get_admin_credentials()

print("\n请选择功能：")
print("1️⃣ 创建邮箱")
print("2️⃣ 设置配额")
print("3️⃣ 删除邮箱")
print("4️⃣ 修改密码")
choice = input("请输入对应数字：").strip()

if choice == "1":
    create_mailboxes()
elif choice == "2":
    update_quotas()
elif choice == "3":
    delete_mailboxes()
elif choice == "4":
    update_passwords()
else:
    print("❌ 无效的选择")
